package in.droom.analyticslibrary;

public class SingletonClass {
    private static final SingletonClass ourInstance = new SingletonClass();

    public static SingletonClass getInstance() {
        return ourInstance;
    }

    private SingletonClass() {
    }
}

package in.droom.analyticslibrary;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey
    @NonNull
    private int user_id;

    @ColumnInfo(name = "Event_Name")
    String event_name;

    @ColumnInfo(name = "Event_Type")
    private String event_type;

}

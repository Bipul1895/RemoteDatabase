package in.droom.analyticslibrary;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import androidx.annotation.Nullable;

public class MyDatabaseAdapter {
    MyHelper helper;
    Context context;

    public MyDatabaseAdapter(Context context) {
        helper = new MyHelper(context);
        this.context = context;
    }

    public long InsertData(String name, String password) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(helper.NAME, name);
        values.put(helper.PASSWORD, password);
        long id = db.insert(helper.TABLE_NAME, null, values);
        return id;
    }

    public String ShowAllData(){
        StringBuffer str=new StringBuffer();
        SQLiteDatabase db=helper.getWritableDatabase();
        String[] columns={helper.UID, helper.NAME, helper.PASSWORD};
        Cursor cursor=db.query(helper.TABLE_NAME,null,null,null,null,null,null);
        while(cursor.moveToNext()){
            // to get column index use :
            int myid=cursor.getInt(0);
            String myname=cursor.getString(1);
            String mypass=cursor.getString(2);
            str.append(myid+ " " + myname+" "+ mypass+"\n");
        }
        return str.toString();
    }

    public String ShowMeData(String name){
        StringBuffer str=new StringBuffer();
        SQLiteDatabase db=helper.getWritableDatabase();
        String[] columns={helper.UID,helper.NAME,helper.PASSWORD};
        String[] selectionargs={name};
        Cursor cursor=db.query(helper.TABLE_NAME,columns,helper.NAME+"=?" ,selectionargs,null,null,null);
        while(cursor.moveToNext()){
            int index1=cursor.getColumnIndex(helper.UID);
            int index2=cursor.getColumnIndex(helper.NAME);
            int index3=cursor.getColumnIndex(helper.PASSWORD);
            int myid=cursor.getInt(index1);
            String myname=cursor.getString(index2);
            String mypass=cursor.getString(index3);
            Log.d("TAG", "ShowMeData: "+myname);
            //int tell=name.compareTo(myname);
            str.append(myid+ " " + name+" "+ mypass+"\n");
        }
        //String mystr=str.toString();
        //Log.d("Mydatabaseadapter : ",mystr);
        return str.toString();
    }

    public int UpdateData(String oldName, String newName){
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(helper.NAME,newName);
        String[] whereArgs={oldName};
        int count=db.update(helper.TABLE_NAME,values,helper.NAME+"=?",whereArgs);
        return count;
    }

    public int DeleteData(){
        SQLiteDatabase db=helper.getWritableDatabase();
        int num=db.delete(helper.TABLE_NAME,null,null);
        return num;
    }

    private class MyHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "MyDatabase";
        private static final String TABLE_NAME = "MyTable";
        private static final int DATABASE_VERSION = 2;
        private static final String UID = "_id";
        private static final String NAME = "Name";
        private static final String PASSWORD = "Password";
        private static final String CREATE_TABLE = " CREATE TABLE " + TABLE_NAME + " (" + UID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NAME + " VARCHAR(255), " + PASSWORD + " VARCHAR(255)); ";
        private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME + " ";

        public MyHelper(@Nullable Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            //this.context=context;
            Message.message(context, "ConstructorCalled");
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(CREATE_TABLE);
                Message.message(context, "OnCreateCalled");
            } catch (SQLException e) {
                Message.message(context, "" + e);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                db.execSQL(DROP_TABLE);
                onCreate(db);
                Message.message(context, "OnUpgradeCalled");
            } catch (SQLException e) {
                Message.message(context, "" + e);
            }
        }
    }
}

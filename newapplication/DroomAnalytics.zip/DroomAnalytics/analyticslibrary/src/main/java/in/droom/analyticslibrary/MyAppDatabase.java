package in.droom.analyticslibrary;

import androidx.room.Database;

@Database(entities = {User.class}, version = 1)
public abstract class MyAppDatabase {
    public abstract MyDao myDao();
}
